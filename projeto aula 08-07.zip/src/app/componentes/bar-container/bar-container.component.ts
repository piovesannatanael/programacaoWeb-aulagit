import { Component, OnInit } from '@angular/core';
import {NgOptimizedImage} from "@angular/common";

@Component({
  selector: 'app-bar-container',
  templateUrl: './bar-container.html',
  standalone: true,
  imports: [
    NgOptimizedImage
  ],
  styleUrls: ['bar-container.css']
})
export class BarContainerComponent implements OnInit {

  constructor() {

  }

  ngOnInit(): void {
  }

}


