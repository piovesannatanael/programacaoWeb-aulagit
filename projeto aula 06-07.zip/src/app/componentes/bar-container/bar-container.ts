

//export class BarContainer implements OnInit {

  //constructor() { }

//  ngOnInit(): void {
  //}

//}
