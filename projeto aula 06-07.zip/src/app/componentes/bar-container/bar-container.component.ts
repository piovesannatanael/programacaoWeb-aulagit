import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-container',
  templateUrl: './bar-container.html',
  styleUrls: ['bar-container.css']
})
export class BarContainerComponent implements OnInit {

  constructor() {

  }

  ngOnInit(): void {
  }

}


